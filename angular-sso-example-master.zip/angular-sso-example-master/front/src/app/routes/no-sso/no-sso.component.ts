import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-sso',
  templateUrl: './no-sso.component.html',
  styleUrls: ['./no-sso.component.scss']
})
export class NoSsoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
